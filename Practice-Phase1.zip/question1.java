import java.util.Scanner;
public class question1 {
	    public static void main(String[] args) {
	        Scanner scanner = new Scanner(System.in);  
	        System.out.print("Enter an Integer: ");
	        int integerNum = scanner.nextInt(); 
	        long longNum = integerNum; 
	        float floatNum = longNum; 
	        double doubleNum = floatNum;    
	        System.out.println("\nImplicit Type Casting:");
	        System.out.println("Integer: " + integerNum);
	        System.out.println("Long: " + longNum);
	        System.out.println("Float: " + floatNum);
	        System.out.println("Double: " + doubleNum);     
	        System.out.print("\nEnter a double number: ");
	        double doubleValue = scanner.nextDouble();   
	        float floatValue = (float) doubleValue; 
	        long longValue = (long) floatValue; 
	        int intValue = (int) longValue;    
	        System.out.println("\nExplicit Type Casting:");
	        System.out.println("Double: " + doubleValue);
	        System.out.println("Float: " + floatValue);
	        System.out.println("Long: " + longValue);
	        System.out.println("Integer: " + intValue);   
	        scanner.close();
	    }
	}


