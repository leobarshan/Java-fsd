import java.util.List;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.LinkedList;

public class question5
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        List<Integer> arrayList = new ArrayList<>();
        List<String> linkedList = new LinkedList<>();
        System.out.println("Enter integers to add to the ArrayList (enter -1 to stop):");
        int num;
        while ((num = scanner.nextInt()) != -1)
        {
            arrayList.add(num);
        }
        System.out.println("Enter strings to add to the LinkedList (enter 'exit' to stop):");
        scanner.nextLine(); 
        String input;
        while (!(input = scanner.nextLine()).equalsIgnoreCase("exit"))
        {
            linkedList.add(input);
        }
        System.out.println("\nElements of ArrayList:");
        for (int value : arrayList) {
            System.out.print(value + " ");
        }
        System.out.println("\nElements of LinkedList:");
        for (String value : linkedList) {
            System.out.print(value + " ");
        }
        scanner.close();
    }
}
