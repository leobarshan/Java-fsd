
import java.util.Scanner;

class question4
{
    int num1;
    int num2;

    question4()
    {
        num1 = 0;
        num2 = 0;
    }

    question4(int a, int b)
    {
        num1 = a;
        num2 = b;
    }

    question4(question4 obj) 
    {
        num1 = obj.num1;
        num2 = obj.num2;
    }

    void display() 
    {
        System.out.println("num1 = " + num1);
        System.out.println("num2 = " + num2);
    }

    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        question4 obj1 = new question4();
        System.out.println("Values using default constructor:");
        obj1.display();
        System.out.print("\nEnter num1 for parameterized constructor: ");
        int num1 = scanner.nextInt();
        System.out.print("Enter num2 for parameterized constructor: ");
        int num2 = scanner.nextInt();
        question4 obj2 = new question4(num1, num2);
        System.out.println("\nUsing parameterized constructor:");
        obj2.display();
        question4 obj3 = new question4(obj2);
        System.out.println("\nUsing copy constructor:");
        obj3.display();
        scanner.close();
    }
}


