import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class question10
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a string that matches regular expression pattern: ");
        String input = scanner.nextLine();
        System.out.print("Enter a regular expression pattern: ");
        String regularexp = scanner.nextLine();
        Pattern pattern = Pattern.compile(regularexp);
        Matcher matcher = pattern.matcher(input);
        if (matcher.find()) 
        {
            System.out.println("Match found: " + matcher.group());
        } else
        {
            System.out.println("No match found.");
        }
        scanner.close();
    }
}