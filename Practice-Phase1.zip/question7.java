
import java.util.Scanner;

class Outer 
{
    private int outerNum;

    Outer(int outerNum)
    {
        this.outerNum = outerNum;
    }

    class Inner 
    {
        void display()
        {
            System.out.println("Value of outer number in Inner class: " + outerNum);
        }
    }
}

public class question7
{
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a value for outer number: ");
        int num = scanner.nextInt();
        Outer outerObj = new Outer(num);
        Outer.Inner innerObj = outerObj.new Inner();
        innerObj.display();
        scanner.close();
    }
}

