import java.util.Scanner;

class DefaultClass 
{
	 void display() 
	 {
	     System.out.println("This is a default access class.");
	 }
}
	public class question2
	{
	 private int privateVar;
	 
	 protected int protectedVar;
	 
	 public int publicVar;
	 
	 int defaultVar;
	 
	 private void privateMethod() 
	 {
	     System.out.println("This is a private method.");
	 }
	 
	 protected void protectedMethod() 
	 {
	     System.out.println("This is a protected method.");
	 }
	 
	 public void publicMethod() 
	 {
	     System.out.println("This is a public method.");
	 }
	 
	 void defaultMethod() 
	 {
	     System.out.println("This is a default method.");
	 }
	 
	 public static void main(String[] args) {
	     question2 obj = new question2();
	     Scanner scanner = new Scanner(System.in);
	     
	     System.out.print("Enter a value for privateVar: ");
	     obj.privateVar = scanner.nextInt();
	     
	     System.out.print("Enter a value for protectedVar: ");
	     obj.protectedVar = scanner.nextInt();
	     
	     System.out.print("Enter a value for publicVar: ");
	     obj.publicVar = scanner.nextInt();
	     
	     System.out.print("Enter a value for defaultVar: ");
	     obj.defaultVar = scanner.nextInt();
	     
	     System.out.println("\nPrivate variable: " + obj.privateVar);
	     System.out.println("Protected variable: " + obj.protectedVar);
	     System.out.println("Public variable: " + obj.publicVar);
	     System.out.println("Default variable: " + obj.defaultVar);
	     
	     obj.privateMethod();
	     obj.protectedMethod();
	     obj.publicMethod();
	     obj.defaultMethod();
	     
	     DefaultClass defaultObj = new DefaultClass();
	     defaultObj.display();
	     
	     scanner.close();
	 }
	}
